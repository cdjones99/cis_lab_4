#include <cmath>
#include <string>
#include <iomanip>
#include <iostream>

using namespace std;

int main() {

	//const double PI = 3.141592653;
	//int degrees;
	//double radians;

	//cout << "Enter a value for the degree of an angle\n";
	//cin >> degrees;

	//radians = degrees* PI / 180;
	//double result1 = sin(degrees * PI / 180);
	//double result2 = cos(degrees * PI / 180);
	//double result3 = tan(degrees * PI / 180);

	//cout << "The degrees entered were: " << degrees << endl;
	//cout << "This equals: " << radians << " in radians" << endl;
	//cout << "The sine of the angle entered is: " << result1 << endl;
	//cout << "The cosine of the angle entered is: " << result2 << endl;
	//cout << "The tanget of the angle entered is: " << result3 << endl;
	//cout << endl;








	string fullName, first, second, third, locale, city, state;

	fullName = first + " " + second + " " + third;

	cout << "Enter your full name:";
	getline(cin, fullName);

	cout << fullName << endl;
	cout << fullName << " " << "is" << " " << fullName.length() << " " << "characters long.\n";

	locale = city + " " + state;

	cout << "Enter your city and state separated by a comma and a space:";
	getline(cin, locale);

	cout << locale << endl;

	system("pause");
	return 0;

}